(function() { 
	const template = document.createElement('template')
	template.innerHTML = `
	
<body>
    <div class="notification-form">
        <h2>Notifications</h2>
        <div class="notification-list" id="notificationList">
            <!-- Notifications will be injected here by JavaScript -->
        </div>
    </div>
</body>

<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.notification-form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 300px;
}

.notification-form h2 {
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 24px;
    color: #333;
    text-align: center;
}

.notification-list {
    max-height: 300px;
    overflow-y: auto;
}

.notification {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
}

.notification:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.notification-date {
    font-size: 14px;
    color: #888;
    margin-bottom: 5px;
}

.notification-message {
    font-size: 16px;
    color: #333;
    }
</style>
	`;

	//var items;
	var dragSrcEl = null;
	class NotificationMain extends HTMLElement {

		
		constructor() {
			super(); 
			this._shadowRoot = this.attachShadow({mode: 'open'});
			this._shadowRoot.appendChild(template.content.cloneNode(true));
			this.currentUser=""
			this.notificationList = this._shadowRoot.getElementById('notificationList');
			//container for the drill path boxes 
			// this._container = this._shadowRoot.getElementById('container');
			// //the 6 boxes that will hold the drill path options 
            // this._box1 = this._shadowRoot.getElementById('box1');
            // this._box2 = this._shadowRoot.getElementById('box2');
            // this._box3 = this._shadowRoot.getElementById('box3');
            // this._box4 = this._shadowRoot.getElementById('box4');
            // this._box5 = this._shadowRoot.getElementById('box5');
            // this._box6 = this._shadowRoot.getElementById('box6');

			// this._box1.addEventListener('click', this._buttonClicked.bind(this,this._box1));
            // this._box2.addEventListener('click', this._buttonClicked.bind(this,this._box2));
            // this._box3.addEventListener('click', this._buttonClicked.bind(this,this._box3));
			// this._box4.addEventListener('click', this._buttonClicked.bind(this,this._box4));
            // this._box5.addEventListener('click', this._buttonClicked.bind(this,this._box5));
            // this._box6.addEventListener('click', this._buttonClicked.bind(this,this._box6));


			// //the selected value in the drillpath
			// //default it to the first value / box 1
			// this.selectedBox=this._box1;
			// this.numberOfSelectedBox ='0';
			// this.drillpathSelectedIndex="0";

			// this.drillpathSelectedID="";
			// this.drillpathSelectedDescription="";

			// //array for the boxes in the drillpath
			// this.boxArray = [this._box1,this._box2,this._box3,this._box4,this._box5,this._box6];
			
            // // Sample text array for testing
            // this.descriptionArray = ['Value 1', 'Value 2', 'Value 3', 'Value 4','Value 5',"Value 6"];
			// this.idArray = ['Value 1', 'Value 2', 'Value 3', 'Value 4','Value 5',"Value 6"];


            // Initial content update, selected item/css/ hiding boxes / populating content
            //this._updateContent();
			//this._setHoverEffects();

			// Sample JSON data representing notifications
			this.notifications = [
				{
					"date": "2024-08-28T10:30:00",
					"message": "New fetaures available "
				},
				{
					"date": "2024-08-29T12:45:00",
					"message": "New update available for your application."
				},
				{
					"date": "2024-08-27T09:15:00",
					"message": "You have a new message  ."
				}
			];
	
			
			
	
			
	
			// Initial render of notifications
			//this._renderNotifications();
			

			this.addEventListener("click", event => {
				var event = new Event("onClick");
				this.dispatchEvent(event);
			});

			this._props = {};
			} //end constructor 

			// Function to fetch the JSON file and check for the matching dashboardName and userID
			async checkDontShowAgain() {
				try {
				// Fetch the JSON file
				const response = await fetch('/dashboards.json');
			
				// Check if the response is ok
				if (!response.ok) {
					throw new Error("Error fetching the JSON file.");
				}
			
				// Parse the JSON data
				const data = await response.json();
			
				// Check if the dashboardName exists
				if (!data[dashboardName]) {
					console.error(`Error: Dashboard with name ${dashboardName} not found.`);
					return;
				}
			
				// Get the users list under the matching dashboardName
				const users = data[dashboardName];
			
				// Check if the currentUserID exists in the dashboard
				if (!users[currentUserID]) {
					console.error(`Error: User with ID ${currentUserID} not found in dashboard ${dashboardName}.`);
					return;
				}
			
				// If both the dashboard and user are found, get the dontShowAgain value
				const dontShowAgain = users[currentUserID].dontShowAgain;
				console.log(`dontShowAgain for user ${currentUserID} in dashboard ${dashboardName}:`, dontShowAgain);
				} catch (error) {
				console.error("Error:", error);
				}
			}

			// Function to render notifications
			_renderNotifications() {
				//var notificationList = this._shadowRoot.getElementById('notificationList');
	
				// Sort notifications by date
				this.notifications.sort((a, b) => new Date(b.date) - new Date(a.date));
	
				// Clear current notifications
				this.notificationList.innerHTML = '';
	
				// Append sorted notifications to the list
				this.notifications.forEach(notification => {
					const notificationElement = document.createElement('div');
					notificationElement.className = 'notification';
					notificationElement.innerHTML = `
						<div class="notification-date">${this._formatDate(notification.date)}</div>
						<div class="notification-message">${notification.message}</div>
					`;
					this.notificationList.appendChild(notificationElement);
				});
			}
			// Function to format the date
			_formatDate(dateString) {
				var options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
				return new Date(dateString).toLocaleDateString(undefined, options);
			}

			 //called when a month button is clicked. updates the new selected box 
			 _buttonClicked(BoxSelected) {
			  }

			onCustomWidgetBeforeUpdate(changedProperties) {
			this._props = { ...this._props, ...changedProperties };
			}


			onCustomWidgetAfterUpdate(changedProperties) {
				if ("userID" in changedProperties) {
					//here call code to update the drill path 
					this.currentUser = changedProperties["userID"];
					this.checkDontShowAgain();
				}
			}

			onCustomWidgetResize (width, height) {
				
			  }

	}

		customElements.define('notification-main', NotificationMain)
	  })()
